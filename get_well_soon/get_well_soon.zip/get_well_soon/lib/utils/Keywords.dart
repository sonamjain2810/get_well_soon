class Keywords {
  static const List<String> adsKeywords = <String>[];
}
