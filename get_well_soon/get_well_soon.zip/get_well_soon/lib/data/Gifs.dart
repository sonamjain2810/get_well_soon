class Gifs {
  Gifs._();
  static const gifs_path = [
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/1.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/2.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/3.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/4.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/5.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/6.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/7.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/8.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/9.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/10.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/11.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/12.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/13.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/14.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/15.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/16.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/17.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/18.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/19.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/20.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/21.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/22.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/23.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/24.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/25.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/26.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/27.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/28.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/29.gif",
    "http://andiwiniosapps.in/baby_shower_wishes/gifs/30.gif",

    
  ];
}
