class Messages {
  Messages._();

  static const english_data = [
  "Wishing you a magical and memorable few years of upcoming babyhood. All the best. We love you."
  ,
"Sending happy thoughts your way as you prepare to welcome a little someone new to your family."
  ,
 "Happy baby shower to mother to be, just when whole life is about to change upside down remember you will always have your family."
  ,
 "The most amazing feeling is when the baby comes out, it’s like you already gave your heart to someone. Have a happy baby shower!"
  ,
 "Well, I just want to say to have a happy life ahead with your one because that’s the moment you will live that most. Happy baby shower!"
  ,
"Babies are a gift from heaven. Enjoy your new addition and may you have a happy and healthy long life together."
  ,
 "Sending happy thoughts your way as you prepare to welcome a little someone new to your family."
  ,
 "Wishing you and your family the best on the coming birth of a new special person."
  ,
"Our heartfelt wishes to you as you step into this exciting new phase in life. Be ready for busy days, sleepless nights, many questions and endless love!"
  ,
"The addition of a new baby brings with it the chance to love and cherish to your heart’s content."
  ,
 "Cherish every moment of everyday between you, your family, and your new little bundle of joy."
  ,
 "Congratulations on the upcoming birth of your new baby. Wishing you the best in health and happiness."
  ,
"Baby booties, baby toys, baby shower, baby joys. Warmest wishes to you and your baby."
  ,
"I am overjoyed and am looking forward to meeting your new baby. Wishing you and your family a healthy life together. Happy baby shower!"
  ,
"This little guy is already blessed with amazing parents. We can’t wait to watch your family grow."
  ,
"Warmest wishes to you as you enter this exciting new adventure. All the best to you and your baby!"
  ,
 "I could not believe I am going to be a grandmother feels like I am on cloud nine, thank you for giving us this happiness. Have a happy baby shower!"
  ,
 "May god bless you and your child with good health and happiness. Stay strong and keep yourself super healthy. Happy baby showering!"
  ,
 "Ho raha naye mehmaan ka intezaar, bhar ke aayega jholi me khushiya hazaar, Hum sab yehi dua karte bhut acha hoga tumhara ye baby shower!"
  ,
 "Children are considered a gift. May your home be blessed with the gift of your new baby."
  ,
 "We are all looking forward to the arrival of the newest addition to your family."
  ,
 "The addition of a new baby brings with it the chance to love and cherish to your heart’s content."
  ,
"We’re tutu excited to meet your darling daughter. Best wishes for the pregnancy."
  ,
"What an exciting time for you both! We hope the upcoming arrival of your new family member all goes well."
  ,
"A beautiful little girl to play with and adore, to spoil a little and love a lot, who could ask for more!"
  ,
 "Congratulations on the new life you are getting ready to bring into the world."
  ,
 "You are going to be a wonderful mother to your new little bundle of joy."
  ,
"The cuddling, the snuggling, the kissing and the loving. All of it you get to enjoy with the arrival of your new little bundle of joy."
  ,
"Ahhh! Freaking out over here. Kudos, you guys. So happy for you two, that’s going to be one lucky baby."
  ,
"Feelings are the true legacy of a lifetime. May you bring the same love and warmth your mother passed onto you so that your little one too can pass on her legacy to her children."
  ,
"Congratulations! Your home will soon be filled with toys and will never be quiet again. Your house will often be a mess and you’ll frequently be tired. But there will always be love and laughter! All the best and many happy memories."
  ,
"Wishing you all the best with the new baby which, is not far away now. Please let us know if you need absolutely anything along the way. Very excited for the both of you."
  ,
 "I am so happy to know your family will soon have an additional member."
  ,
 "Best wishes and plenty of health throughout the remainder of your pregnancy. We look forward to meeting your new baby."
  ,
 "I wish you all the best in the upcoming months before you give birth to a sweet new member for your family."
  ,
"If you are worried about not having enough space when the baby comes, get rid of your bed. You won’t be using it for a while anyway. Congratulations!"
  ,
"May you touch dragonflies and stars, dance with fairies and talk to the moon. May you grow up with love and gracious hearts and people who care. Welcome to the world little one, it has been waiting for you."
  ,
"Many hearty congratulations on your new bundle of joy! This upcoming baby is your real blessing filling your hearts with lots of wonderful memories. I wish you the best happiness and good luck to the life’s awesome treasure!"
  ,
 "I am blessed to have a daughter like you and I wish that you can say that too. I wish you a very happy shower and lifetime happiness with your baby!"
  ,
 "Your expectation of a bouncing and healthy baby will be surely fulfilled. Have a safe delivery."
  ,
 "As you look forward to rock your little angel in your hands and bosom, the strength, grace and resources that you need will come forward in a miraculous way!"
  ,
 "Children are heritage from the Lord. This special heritage on the way will pave way for greater accomplishments in your family."
  ,
 "I can see sparkles in your eyes as you look forward to holding and to cherishing your little angel on the way. Congratulations in advance!"
  ,
 "The restlessness you feel, the constant kicks on in your womb, the occasional leaps that cause you discomfort, and the morning sickness that often irritate you will all soon give way for immeasurable joy at the arrival of your baby. Congrats!"
  ,
 "There’s unspeakable joy when a baby is born. That’s the kind of joy that is coming your way as you look forward to the arrival of your little cute angel."
  ,
 "Don’t forget to take care of yourself, so that you can stay strong and healthy as you expect your cute little angel. Congratulations all the way!"
  ,
 "A new addition to a family is a new upliftment and advancement, and that is what your new baby is bringing with him. Happy baby shower celebration!"
  ,
 "Words cannot express how much joy I feel in my heart for you. My prayer is that your baby will arrive in good health and in perfect shape."
  ,
 "Even if I’m not there at your baby shower, my love is ever present with you, and my prayer of protection is roundabout you every day. I wish you a safe and sound delivery."
  ,
 "You also need lots of love and cuddling just like the baby on the way, which is why I’m spreading my hands wide in loving care and embrace."
  ,
 "Go girl, we are in this together and our prayer is with you every inch of the way as we count down to your delivery day."
  ,
 "A special child is on the way. Give him all the care and love in the world when he arrives. Of course, don’t forget to take care of yourself too. Congrats!"
  ,
 "When I was about become a mother I was so worried all the time how would I raise a child but then you automatically happened to be god gifted and so is your baby!"
  ,
 "From a mother to another mother to be, life could be difficult at times with baby but 5 minutes pain to lifetime of happiness. Happy baby shower!"
  ,
"Your home will soon be filled with toys and will never be quiet again. Your house will often be a mess and you’ll frequently be tired. But there will always be love and laughter. All the best and many happy memories!"
  ,
 "There is nothing quite as wonderful as the birth of a new baby. Wishing you love and health during this time."
  ,
 "Your baby will soon be here! Sending love and warm wishes to you during this special time."
  ,
 "Wishing you the best of luck on the upcoming birth of your precious little baby."
  
"Congratulations to the amazing mom! We know it is an exciting time for you and we pray to the Almighty that the rest of your pregnancy and birth goes well. May your baby bring you rejoice that lasts forever. From bottom of our heart, we wish you healthy and safe pregnancy!"
  ,
"Acknowledge how lucky, as parents you are. Smile, as you gaze into your newborn’s eyes. Soak in the joy of having a baby and appreciate your life’s biggest prize. Wishing you two(almost three) all the best."
  ,
"Sincere congratulations on your upcoming start to a new department-you are adding love to the world. There is nothing more precious for a mother than having her baby. We are excited to meet the new baby of your family in couple of weeks. We wish you a safe delivery!"
  ,
 "Dearest mother to be, you are going to have one amazing journey of your life, May god bless you on every step. Happy baby shower!"
  ,
 "Having a baby is a planned thing but when it is put to action and you realize it’s time then that is when you panic but don’t. Enjoy every moment of baby shower!"
  ,
"Precious one, so small, so sweet, dancing in on Angel’s feet, straight from heaven’s brightest star, what a blessing you truly are."
  ,
"Congratulations! Wish you endless love and boundless patience for making your new role as super parents a grand success!"
  ,
"A precious gift all bundled and tied, best wishes for you and your baby inside. Many congratulations to you!"
  ,
"Welcome to the world little one. Wishing you a lifetime of happiness, laughter and joy."
  ,
 "The bump looks nicer to me and so you’re healthy. I believe you are having a nice diet to have a healthy baby. Have an amazing baby shower!"
  ,
 "A mother is more than everything; she is a feeling of love, joy, sadness, happiness, care, warmth, protection. Hope you will have good one. Wishes for baby shower!"
  ,
 "Cheers to hoping for ride of unconditional love and motherhood. The journey is going to never end because it’s just started. Baby shower blessings!"
  ,
"Looking at your baby reminds us of how beautiful a gift the God and the Heaven above has bestowed on you. Baby shower warm wishes to both of you!"
  ,
"Get ready for toy cars in all shapes and sizes, for balls, bats, and bikes, and all sorts of surprises. Congratulations on your little man."
  ,
"Warmest congratulations to you and your new little one. May you have lots of love, kisses and snuggling in the future."
  ,
 "You will always feel a little low about certain part in your life but trust me when the baby’s out, you will be crying with happiness. Have a happy baby shower!"
  ,
 "A baby shower is a feeling that reminds you of motherhood, care, support which your baby will need. So here it comes hope you an amazing motherhood journey."
  ,
 "Wishing you a happy baby shower, may god always bless good health to your baby and you. My best wishes and regards."
  ,
"There will be hands carrying you, arms in which you will be safe and people who will show you that you are welcome!"
  ,
"Booties and bonnets, ribbons and lace, little stuffed toys all over the place. Congratulations on your sweet little girl."
  ,
"I look forward to being a part of this new journey. I can’t wait to help you with your little bundle of joy. Congratulations!"
  ,
 "Welcoming to the tribe or let’s say to the ‘mom’ tribe. Hope you always share your bit of heart and feel relaxed. Baby shower wishes!"
  ,
 "From ‘I seriously don’t want to become mom’ to ‘having a baby shower’ how do you feel?Have a wonderful baby shower!"
  ,
"Baby, may you be strong, brave, fearless. But also be kind, gentle, and forgiving! Be the best of the best!"
  ,
"Congrats, we are so happy for you! Enjoy your journey into parenthood and have fun! We are wishing the best for you three in the coming months."
  ,
"Thanks for inviting us along to share in the excitement of your soon to be new arrival. Wishing you all the best with babyhood."
  ,
 "Dear friend, well at least now you have new set of dresses and clothes to wear. Hope you have a happy baby shower!"
  ,
 "Don’t worry about your figure we have got you covered, taken a gym membership in advance. Happy baby shower!"
  ,
 "Well, it looks like a nightmare to clean the dirty diapers and stuff of the baby but you will get used to it and eventually end up loving. Baby shower wishes!"
  ,
"A little one has joined you both, how happy you must be. It was great when there were two of you, but even better when there are three."
  ,
"You are having a fantastic little boy, with the cutest nose and perfect smile. He seems to have mommy’s gorgeous eyes, and comes with a truckload of style!"
  ,
"Oh boy! We can’t wait to meet him. Thanks for inviting us to share in your baby shower celebrations."
  ,
 "Now you will have enough time to run behind your kid and play which means you can relive your childhood. Wishing you a happy baby shower!"
  ,
 "Having a baby is more like a feeling you can’t say to anyone, you feel unsaid pressure and you feel funny about just suddenly becoming a mom but that’s fine. Baby shower wishes!"
  ,
"We’re all so happy for you both with your expected new arrival!! Good luck with babyhood and as always please let us know if we can help out in any way. All the best."
  ,
"Tiny fingers and tickly toes, cowboy boots and trucks to tow. A bundle of joy, created by love. A precious gift, from Heaven above."
  ,
"The little angel is here, and everyone’s coming to cheer. She is the perfect combination of princess and warrior."
  ,
 "Well, you are going to turn 2 not your age by actually by numbers this time. So, I wish you the best and a happy baby shower!"
  ,
 "To all those endless cravings and asking your husband to fulfill it is just amazing. The days are ending soon take the most of it. Have a happy baby shower!"
  ,
"Here’s to smiles, laughter, patience and joy. We hope you get a healthy baby girl or boy."
  ,
"A baby boy arrives, and just like that everything changes. The world gets bigger, the heart grows fuller, and the life gets better as he is in it."
  ,
"Thanks for inviting us to share in your baby shower celebrations!! We hope your soon to be new baby arrives safe and sound. All the best."
  ,
 "It’s a beautiful thing, I just known like a party animal person who turned into a saint after knowing she was pregnant. So have an amazing baby shower!"
  ,
 "I wish the baby is as wonderful as you and as beautiful as your husband. Wishing you life filled with love ahead, warm wishes for baby shower!"
  ,
"Wishing you a happy and healthy baby and I hope your life only gets better from now on. Happy baby shower and I’m confident that you will be great parents to your child!"
  ,
 "May the baby inherit all the good traits of mother and father, wishing you both congratulations. Warm wishes for baby shower!"
  ,
 "To soon going to be mother and father, how does it feel someone would actually start calling you ‘mama’ and dada’? Well hope you have a gorgeous baby shower!"
  ,
 "I still can’t believe you are soon going to be parents and that’s like a dream to me. Baby shower wishes, we are still going to shop!"
  ,
 "Congratulations to new mom and dad, a toast to them. May you always find piece within and love out, may the baby be second kind of god. Have a happy baby shower!"
  ,
 "Warm wishes for baby shower, it’s going to be a hone for toddler and hope to see you becoming one. Wish you the best journey!"
  ,
"A new baby is like the beginning of all things wonder, hope, a dream of possibilities. – Eda J. Le Shan"
  ,
 "It’s just feels like a moment when you were married and now you are announcing parents. I am so proud and overwhelmed. Warm wishes for baby shower!"
  ,
 "It’s for some other person to rule in the house, no more your turn only baby’s turn. Have a beautiful baby shower and capture the moments!"
  ,
 "I am going to be aunt! Oh my god I am so happy for you sister and the bump looks nicer. Have a happy baby shower sis!"
  ,
 "So, my trip is confirmed I am going to be there with you till your delivery. May god bless you with good healthy sister, happy baby showering!"
  ,
 "Well, I was your kid all my life and now you are actually going to have a baby, I can’t believe but I wish you a happy baby shower and enjoy every bit of motherhood!"
  ,
 "You just have to sit back relax and enjoy the bump. This is your moment and save it for you baby. Happy baby showering!"
  ,
 "May this baby enlightens your world and bring out the best in you. I wish you a very happy baby shower and blessings upon the baby boo!"
  ,
 "Have a happy baby shower dearest sister, I wish this baby inherits every trait of yours because you are the best. Love you!"
  ,
 "May all the stars shine for the baby and may god always shower his blessings upon both of you. Happy baby showering sister!"
  ,
 "To all the surprises for the baby in coming into this new amazing world. I wish good health for both of you. Have a happy baby shower sister. Love you!"
  
  ];

  static const french_data = [
 //boys
"His touch will melt our hearts and his smile will make our day. Waiting for your little one so eagerly. May you have a healthy delivery!"
  ,
"Happy hearts full of joy, soon to welcome your baby boy! May your home be filled with laughter, love, smiles, and hugs. Congratulations."
  ,
"We are thrilled to hear about your soon-to-be miracle! Boys bring so much energy and laughter to every home; relish every moment."
  ,
"Here he comes! I hope you’re ready for all the bright eyes and mischievous smiles to melt your heart. Enjoy the beginning of your new and exciting journey!"
  ,
"Get ready for your heart to swell with pride. The moment you lay eyes on your beautiful new baby boy will change your life forever. I am so thrilled for you!"
  ,
"Little boys bring love and joy! I am excited to watch your family grow with this new little addition. May he brighten every day and make you proud every moment."
  ,
"Your baby boy will soon be here; your heart will swell with pride. Raise him up with love and joy, and always be his guide."
  ,
"Let the fun begin! Your little man is almost here; we hope his arrival is the beginning of a lifetime of happy memories and proud moments."
  ,
" He may outgrow your lap, but he’ll never outgrow your heart."
  ,
" Here’s to the next chapter in your life! We hope your new baby boy has his father’s laughter, his mother’s heart, and a spirit that outshines them both."
  ,
" His little feet will surely make the biggest footprint in our hearts. Waiting for the arrival of your prince charming. May you have a blessed baby shower day!"
  ,
" Here comes a brand new little boy, to fill all our hearts and lives with joy!"
  ,
" Your son doesn’t know it yet, but he’s about to get the best parents ever!"
  ,
" A baby boy arrives, and just like that everything changes. The world gets bigger, the heart grows fuller, and life gets better as he is in it."
  ,
" Thank you for inviting us to your baby shower celebrations; we cannot wait to see your baby boy."
  ,
"Get ready for baseball games, bike rides, and many more surprises, congratulations and welcome to motherhood."
  ,
"His little feet will surely make the biggest footprint in our hearts. Waiting for the arrival of your prince charming. May you have a blessed baby shower day!"
  ,
" Congratulations on your upcoming little guy. May God bless you with a safe delivery!"
  ,
" The little guy is already lucky as he is getting to be a part of your amazing family. Congratulations and all the best."
  ,
" Having a baby is the most wonderful experience in the world, although you are a bit scared, I am sure you will ace it. All the best darling."
  ,
" If he’s anything like his father, he’ll be a handsome baby boy!"
  ,
"Tiny fingers and tickly toes, cowboy boots, and trucks to tow. A bundle of joy, created by love. A precious gift, from Heaven above."
  ,
"We’re excited to meet your ray of sunshine. Best wishes on your baby boy’s arrival."
  ,
" Can’t wait to meet the new handsome man in your life. I’m sure he’s a keeper!"
  ,
" Your little prince is so lucky to have you as parents. Wishing your family lots of happiness and health."
  ,
" I hope your baby boy’s life is filled with happiness, love and adventure."
  ,
" Oh boy! Let the adventure begin. Congrats on your little crusader."
  ,
" Sending lots of love to your little man. May he always be healthy and safe."
  ,
" Congrats on your new baby boy. With you as parents, he’s sure to be one handsome and kind little boy."
  ,
" Sorry dad, this little boy is about to steal mom’s heart."
  ,
" This baby boy is going to be the greatest blessing. Excited to see how much joy and laughter he’s sure to bring to your home."
  ,
 "You’re having a boy! I’m sure it’ll be endless sticky fingers, plenty of cardio, and a home filled with laughter."
  ,
 "“This little guy is already blessed with amazing parents. We can’t wait to watch your family grow.”"
  ,
"“Oh boy! We can’t wait to meet him. Thanks for inviting us to share in your baby shower celebrations.”"
  ,
" “Can’t wait to meet your little dude!”"
  ,
" I see cars and trucks and dirt and adventure in your near future! Congrats on the soon-to-be addition to your family. I hope your boy fills your life with fun and delight."
  ,
" “Little hands, little feet, and a little trouble are all on the way. Congratulations!”"
  ,
" A bouncing baby boy is cause for celebration. Congratulations!"
  ,
" Congratulations on your baby boy. Just four more and you’ll have a basketball team!"
  ,
" A baby boy arrives, and just like that, everything changes. The world gets bigger, hearts grow fuller, and life means more because he’s in it."
  ,
" Oh boy! I can’t wait to meet him."


  ];
  static const german_data = [
// girls
"We are tickled pink to welcome your baby girl."
  ,
" I am tutu happy you are having a girl!"
  ,
" News of your precious baby girl has us twirling for joy."
  ,
" Sugar, spice, and everything nice is coming your way! We’re so excited for you."
  ,
" A baby girl is on her way, and I can’t wait to go shopping for her! "
  ,
" Welcome to your little Princess! Long may she reign! "
  ,
" We can’t wait to meet Mommy’s mini-me and Daddy’s little girl."
  ,
" “We’re tutu excited to meet your darling daughter — best wishes for the pregnancy.” "
  ,
" “A cradle full of best wishes for your newborn baby girl”"
  ,
"“Twinkle twinkle little star, do you know how loved you are?”"
  ,
" “Little girls bring such delight with hearts so warm and smiles so bright.”"
  ,
" “A baby is a blessing. A gift from heaven above, a precious little angel to cherish and to love.”"
  ,
" Can’t wait to meet your beautiful daughter and best wishes to you both."
  ,
" May your baby girl have your grace, beauty, and strength."
  ,
"A precious baby girl will fill your heart and home with love and joy."
  ,
" Here come the bows, ruffles, and frills! We’re so happy to welcome your sweet baby girl. Very soon your life will change in the very best of ways. Relish every second of it!"
  ,
" Prepare for your heart to be captivated by your precious new arrival. May your dear baby girl bring more giggles and cuddles than you can handle!"
  ,
" Make room for the dolls, the outfits, and everything pink! Your beautiful little bundle is almost here and we are so thrilled to witness the joy she will bring."
  ,
"May your days be filled with disarming smiles, dances in tutus, and sweet lullabies. Your baby girl will bring you more happiness than you can fathom. Congratulations!"
  ,
" We are so excited to be included in the celebration of your soon-to-be baby girl! We know she will be kind, smart, beautiful, and full of love, just like her mom."
  ,
" Here she comes! Be prepared to be wrapped around your precious daughter’s little finger for years and years to come. These will be the best days of your life."
  ,
" What a blessing you’re about to have! Take the time to savor every sweet little giggle, warm hug, and silly game. You’ll cherish the memories forever!"
  ,
"We are overjoyed with the news of your soon-to-be precious baby girl. We’re sure she will fill your life with beauty, grace, and love."
  ,
" A new baby girl will melt your heart faster than anything else in the world! We are excited for the bright and beautiful life your family will have with this precious new addition."
  ,
"Can’t wait to see your baby girl’s smile. She’s going to be one lucky princess."
  ,
" Wishing you a safe delivery. Know that your baby girl is already so loved by many."
  ,
" Boss ladies raise boss babies. Can’t wait to see you be the most amazing mom to your baby girl."
  ,
" God bless you and your sweet baby girl."
  ,
" A baby girl is the world’s most beautiful miracle. Cherish every second of it and best wishes to you both."
  ,
" May your little warrior be as fierce and sassy as her mama."
  ,
" Your daughter will now hold your hearts for the rest of your life. I’m excited to see you be the most wonderful parents to your little angel."
  ,
" It felt great to be able to hold your little princess for the first time. She is truly adorable. Many best wishes to you and your baby girl for the future!"
  ,
" Your daughter will be beautiful, smart, and happy—just like her mother!"
  ,
"A beautiful little girl to play with and adore, to spoil a little and love a lot, who could ask for more!"
  ,
"You can’t comprehend the full meaning of love until the moment you look into your baby girl’s beautiful eyes for the first time. Soak it in, treasure the moment, and fill her future with hopes and dreams."
  ,
"She’s almost here! May her sweet little hands always find a place in yours, and may you be astounded by her grace and love as you watch her grow into a beautiful young lady."
  ,
"Booties and bonnets, ribbons and lace, little stuffed toys all over the place. Congratulations on your sweet little girl."
  ,
"A great joy is coming all wrapped in pink. Can’t wait to meet her!"
  ,
" The littlest feet make the biggest footprints in our hearts. Enjoy this love."
  ,
" Your daughter doesn’t know it yet, but she’s about to get the best parents ever!"
  ,
" Sugar, spice, and everything nice; this is what your new family is made of."
  ,
" Warmest wishes to you as you enter this exciting new adventure. All the best to you and your baby girl!"
  ,
" So excited to know that your family is growing by a little princess. Best wishes for the big day!"
  ,
" Wishing the best for you and your baby girl to be. Prepare yourself for the many exciting changes ahead. May the remainder of your pregnancy days be healthy!"
  ,
" Many thanks to you for making me a part of this beautiful day. I can’t wait to start the shower games already. Best wishes for your baby girl!"

  ];
  static const hindi_data = [
    // twins
 "“Double the giggles, double the grins, double the love, when you have twins! Congratulations.”"
  ,
" “Sending all of my love to your two bundles of joy. May both of your twins be showered in love.”"
  ,
" “With four arms hugging you instead of two, congratulations on having twins!”"
  ,
" “Twins! Sometimes miracles come in pairs.”"
  ,
" “It's twins! Congratulations! Twins mean double the kisses and double the fun. It's double the joy for everyone.”"
  ,
" “Your family just grew by 4 feet! Congratulations on your twin girls /twin boys and all the best.” "
  ,
" “You made one wish. And two came true. Congratulations on your double blessings!”"
  ,
" “Good moms of twins have: sticky floors, messy kitchens, laundry piles, dirty ovens, empty fridges and - happy twins!”"
  ,
" Its twins! Sometimes miracles do come in pairs…"
  ,
"Congratulations on your double trouble!"
  ,
" If there’s anything more special than a new baby, it’s two new babies!"
  ,
" I can’t believe its twins! Twins mean double the kisses and double the fun. Let’s not mention double the hard work and stress…"
  ,
" Having twins means two sets of grins. Here’s hoping the smiles never stop for your new family. "
  ,
" Congratulations! And congratulations again!"
  ,
"One wish made, and two came true. Double the blessings made just for you!"
  ,
"One will cry, and one will laugh, one will weep, and one will sleep. Though the troubles do a double shift, these memories will be worth the keep."
  ,
" Thanks for giving us two precious bundles to cuddle and kiss. We all are so proud of you. May you have healthy motherhood!"
  ,
" Twin sister or brother, how can these siblings live without each other!"
  ,
" It’s double the joy and double the fun. Thanks for introducing us to your pair of miracles. Best wishes for the baby shower."
  ,
" Double the giggles, double the grins. Double the troubles, when you are blessed with twins!"
  ,
" It’s twins! Congratulations! Twins mean double the kisses and double the fun. It’s double the joy for everyone."
  ,
" Congratulations on your double trouble!"
  ,
" Sometimes miracles do come in pairs."
  ,
" Twins! Wow! Sending you twice the love and best wishes times two."
  ,
"Double-cuteness runs in our family. Congrats on keeping the tradition going!"
  ,
"There are many reasons to smile, and you just got two more! Congratulations on your twins."
  ,
"Life has given you twins because it knew you no one is as capable as you to raise them. Congratulations."
  ,
" Get ready for double nappy changes, and double trouble. But you will also receive double kisses and double happiness."

  ];

  static const italy_data = [
    // funny
  "Enjoy the shower today—it might be the last one you get for a while."
  ,
 " Remember how we used to stay up all night partying? Consider that your training for a newborn!"
  ,
 " I’ll come over any time to hold your delicious little baby while you take a nap. I don’t charge much!"
  ,
 " Sleep now or forever hold your peace."
  ,
 " You two were meant to procreate. Congratulations on the new addition!"
  ,
 " Hello, baby. Goodbye, sleep."
  ,
 " One smile from a baby is worth 100 diaper changes. You can do this!"
  ,
 " Dear Baby, please sleep through the night. Love, your mom’s BFF."
  ,
 " You’re a parent. It’s your circus and those are your monkeys."
  ,
"We looked up “amazing parents” on Wikipedia, and your photos popped up. Congrats and have fun with your new delivery."
  ,
 " A perfect example of minority rule is a new baby in the house. Enjoy your new master."
  ,
 " Enjoy this wonderful and exciting baby shower, because it’s the last party you’ll have for a long time."
  ,
 " Parenthood: the scariest hood you’ll ever go through."
  ,
 " Welcome to parenthood where going to the grocery store by yourself is now considered a vacation."
  ,
"Parenting: when hard labor and sleepless nights are paid in smiles."
  ,
"Life just got real! Buckle up, it’s sure to be a bumpy ride."
  ,
 " I see scattered toys, tons of diapers, and sleepless nights in your future. Let the fun begin!"
  ,
 " The greatest gifts really do come in small packages. Congrats on your little one!"
  ,
 "Cheers to the new appreciation for the words “me time” you will soon have!"
  ,
 " Hope you enjoy your baby shower! It’s the last party you’ll be going to in a long time."
  ,
 " Excited to see you’re having a baby, and even more that I’m not. I’ll drink to that!"
  ,
 " A baby makes love stronger, days shorter, savings smaller, and a home happier. "
  ,
 " Having a baby means you’ll finally feel excited about having your in-laws over. "
  ,
 " Seeing you, guys have, just traded your freedom in for parenthood, my advice to you is to celebrate this baby shower like nobody’s business, since it’s going to be the last party you’ll attend in a while."
  ,
 " Did you know that parenting is the most important job on Earth that you do without needing any experience?! Congratulations, soon-to-be parents."
  ,
 " Babies are God’s gift to parents. And I almost envied you guys for the priceless gift coming your way. But then when I remembered that this priceless gift also comes along with a sagging diaper my envy began to disappear."
  ,
 " Congrats to the future Daddy and Mommy. I hope neither of you dropped out of the school of Changing Diapers. If you did, then I guess we all know how interesting this journey into parenthood is going to go."
  ,
 "May your bundle of joy fill your lives with immense joy and happiness. May your little angel also have mercy on you by not giving you too many poopy diapers to deal with."
  ,
 " Becoming a parent is one of the most rewarding experiences in the world. I’m glad you have both decided to take that journey. However, bear in mind that the experience comes along with wearing outdated jeans and watching loads of kids’ movies."
  ,
 " Congratulations, guys, and happy baby shower wishes to you. Now, to an important question. Does either of you know how to change diapers? You better be experts at that because I’ll be the first one to make fun of you if I catch either of you struggling to change your little one’s sagging diapers."
  ,
 " So you decided to have a baby? Great, can’t wait to meet your new master."
  ,
"You better remember this baby shower, this will be one of the last showers you enjoy in peace!"
  ,
 "I’m really looking forward to learning everything about your new baby on social media."
  ,
 "Congratulations – I really hope your new baby is either a girl or a boy!"
  ,
 " Have fun learning how to remove a whole new spectrum of stains."
  ,
 "Kids cry, throw fits, eat all your food, and keep you up all night. Don’t worry, that’s only for the first 18 years… "
  ,
 " “Because I said so.” Is going to be your new catchphrase. "
  ,
 " Just think, in only a few weeks you’re going to have…alcohol again! Oh and a beautiful new baby, of course!"
  ,
 "Don’t worry about the difficulty of raising a child. It is just as easy as running a marathon, doing your taxes, and wrestling an octopus at the same time, every day."
  ,
 " To test to see if you are ready for a baby, try putting a pair of underwear on a kangaroo."
  ,
 " If you are worried about having enough space after the baby comes, you can get rid of your bed. You won’t be using it much for a while, anyway."
  ,
 " I am sure your baby will be really cute, at least as long as they take after their mother."
  ,
"Let the noise begin!"
  ,
"Congratulations on making a human with your genitals."
  ,
"I hope you’re excited – soon you’ll lose 10 pounds in one day!"
  ,
 " Congratulations for making your bulging belly the topic of constant discussion with your friends and family!"
  ,
 " It’s great you’re having a baby I can cuddle, spoil and play with – then give back when they cry. Thanks so much!"
  ,
 " Of all the people who’ve thrown up on you, your baby will be the best!"
  ,
 "Have fun learning how to remove a whole new spectrum of stains!"
  ,
 "Thank you for having a baby I can cuddle, spoil, and love on…then hand back when [he/she] starts to cry."
  

  ];

  static const portugal_data = [
    // Hindi poem
"वृंदावन का कृष्ण कन्हैया सबकी आंखों का तारा,वृंदावन का कृष्ण कन्हैया सबकी आंखों का तारा,मन ही मन क्यों जले राधिका मोहन तो है सबका प्यारा,मन ही मन क्यों जले राधिका मोहन तो है सबका प्यारा,वृंदावन का कृष्ण कन्हैया सबकी आंखों का तारा। जमुना तट पर नंद का लाला जब-जब रास रचाए रे,जमुना तट पर नंद का लाला जब-जब रास रचाए रे,तन-मन डोले कान्हा ऐसी बंसी मधुर बजाए रे,सुध-बुध भूली खड़ी गोपियां जाने कैसा जादू डारा,वृंदावन का कृष्ण कन्हैया सबकी आंखों का तारा। रंग सलोना ऐसा जैसे छाई हो घट सावन की,रंग सलोना ऐसा जैसे छाई हो घट सावन की,ऐ री मैं तो हुई दीवानी मनमोहन मनभावन की,तेरे कारण देख सावरे छोड़ दिया मैंने जग सारा। वृंदावन का कृष्ण कन्हैया सबकी आंखों का तारा,मन ही मन क्यों जले राधिका मोहन तो है सब का प्यारा,वृंदावन का कृष्ण कन्हैया सबकी आंखों का तारा।"
  ,
"एक नए मेहमान के आने की खबर है दिल में लहर है,एक नए मेहमान के आने की खबर है दिल में लहर है,चांद को पलने में बुलाने की खबर है दिल में लहर है। नैनो वाली काहे को तू नैन चुराये, नैन चुराये,बैठी है तू चोर सी क्यों सिर को झुकाए- सिर को झुकाए,मुख न छुपा क्या यह छुपाने की खबर है,एक नए मेहमान के आने की खबर है दिल में लहर है। रोता कोई आएगा इस घर को हंसाने, घर को हंसाने,आस के दीपक से कई दीप जलाने, दीप जलाने,नाचे रे मन नाचने जाने की खबर है,एक नए मेहमान के आने की खबर है दिल में लहर है।"
  ,
"तेरे सपनों का संसार देख संवरने वाला है,सुना है आसमां से चांद उतरने वाला है,अपने आंगन में सितारों को सजाए रखना,अपनी गोद में बहारों को बिछाए रखना,हां, एक नन्हा-सा मेहमान आने वाला है। गोद में तेरी भरी मिठाई जैसा मीठा होगा वो,गोद में तेरे भरे फलों जैसा रसीला होगा वो,होगी तेरी छवि या मेरे मुन्ना जैसा होगा वो,व्याकुल है नैना कि नन्हा मेहमान कैसा होगा वो,के अपने आंगन में नया दीप जलने वाला है,के नन्हे कदमों से कोई छम-छम चलने वाला है,हां, एक नन्हा-सा मेहमान आने वाला है,हां, एक नन्हा-सा मेहमान आने वाला है। राधे कृष्णा करे तेरा हर सुख सपना सच हो जाए,ऐसी गोद भरे तेरे घर के भाग चमक जाए,गोरी तेरे पिया तो तुझसे बड़े ही खुश रहते होंगे,हर पल कदम-कदम पे बड़ा ख्याल तेरा रखते होंगे,हां, उनको भी कोई पापा अब जो कहने वाला है,तेरी गोद में वो फूल खिलने वाला है,हां, एक नन्हा-सा मेहमान आने वाला है। हां, एक नन्हा-सा मेहमान आने वाला है,हां, एक नन्हा-सा मेहमान आने वाला है।"
  ,
"मेरे घर आई…मेरे घर आई एक नन्ही परी..एक नन्ही परी,चांदनी के हसीन रथ पे सवार…मेरे घर आई हो.ओ..मेरे घर आई एक नन्ही परी..एक नन्ही परी उसकी बातों में शहद जैसी मिठास, उसकी सांसों में इत्तर की महकास,होंठ जैसे के भीगे-भीगे गुलाब, गाल जैसे कि दहके दहके अनार,मेरे घर आई..हो..ओ..मेरे घर आई एक नन्ही परी..एक नन्ही परी। उसके आने से मेरे आंगन में खिल उठे फूल, गुनगुनाई बहार,देखकर उसको जी नहीं भरता चाहे देखूं उसे हजारों बार, चाहे देखूं उसे हजारों बार,मेरे घर आई..हो..ओ..मेरे घर आई एक नन्ही परी..एक नन्ही परी। मैंने पूछा उसे के कौन है तू, हंस के बोली के मैं हूं तेरा प्यार,मैं तेरे दिल में थी हमेशा से घर में आई हूं आज पहली बार,मेरे घर आई..हो..ओ..मेरे घर आई एक नन्ही परी..एक नन्ही परी।चांदनी के हसीन रथ पर सवार…मेरे घर आई…मेरे घर आई एक नन्ही परी..एक नन्ही परी।"
  ,
"चंदा है तू, मेरा सूरज है तू, ओ मेरी आंखों का तारा है तू,चंदा है तू, मेरा सूरज है तू, ओ मेरी आंखों का तारा है तू,जीती हूं मैं बस तुझे देखके, इस टूटे दिल का सहारा है तू,चंदा है तू मेरा सूरज है तू…..तू खेले खेल कई…मेरा खिलौना है तू, तू खेले खेल कई… मेरा खिलौना है तू,जिससे बंधी हर आशा मेरी, मेरा वो सपना सलोना है तू,नन्हा-सा है… कितना सुन्दर है तू, छोटा-सा है… कितना प्यारा है तू,चंदा है तू मेरा सूरज है तू…."
  ,
"मुन्ने तू खुश है बड़ा, तेरे गुड्डे की शादी है आज,मुन्ने तू खुश है बड़ा, तेरे गुड्डे की शादी है आज,मैं वारी रे.. मैं बलिहारी रे, घूंघट में गुड़िया को आती है लाज,यूं ही कभी होगी शादी तेरी, दूल्हा बनेगा कुंवारा है तू,चंदा है तू मेरा सूरज है तू… पुरवाई वन में उड़े, पंछी चमन में उड़े,पुरवाई वन में उड़े, पंछी चमन में उड़े,राम करे कभी हो के बड़ा, तू बनके बादल गगन में उड़े,जो भी तुझे देखे वो ये कहे, किस मां का ऐसा दुलारा है तू चंदा है तू, मेरा सूरज है तू, ओ मेरी आंखों का तारा है तू,चंदा है तू, मेरा सूरज है तू, ओ मेरी आंखों का तारा है तू,जीती हूं मैं बस तुझे देखके, इस टूटे दिल का सहारा है तू,चंदा है तू मेरा सूरज है तू….."
  ,
"छोटी-सी, प्यारी-सी, नन्ही-सी आई कोई परी,छोटी-सी, प्यारी-सी, नन्ही-सी आई कोई परी,भोली-सी, न्यारी-सी, अच्छी-सी आई कोई परी,पालने में ऐसे ही झूलती रहे, खुशियों की बहारों में झूमती रहे,गाते मुस्कुराते संगीत की तरह, ये तो लगे रामा की गीत की तरह।छोटी-सी, प्यारी-सी,  नन्ही-सी आई कोई परी,छोटी-सी, प्यारी-सी, नन्ही-सी आई कोई परी,भोली-सी, न्यारी-सी, अच्छी-सी आई कोई परी,पालने में ऐसे ही झूलती रहे, खुशियों की बहारों में झूमती रहे,गाते मुस्कुराते संगीत की तरह, ये तो लगे रामा की गीत की तरह, रा रा रू रा रा रा रा रू … रा रा रू रा रा रा रा रू सरगम जानू न, सुर पहचानू न, जाने कैसे फनकार बन गया,सबसे यारी है, नातेदारी है…जिसको चाहा वो यार बन गया। मुझको तो जो दिया रब ने ही दिया, आया जो दिल में वो मैंने गा लिया..आया जो दिल में वो मैंने गा लिया,गाते मुस्कुराते संगीत की तरह, दुनिया लगे रामा के गीत की तरह,रा रा रू रा रा रा रा रू…. रा रा रू रा रा रा रा रू छोटी-सी, प्यारी-सी, नन्ही-सी आई कोई परी,छोटी-सी, प्यारी-सी, नन्ही-सी आई कोई परी,भोली-सी, न्यारी-सी, अच्छी-सी आई कोई परी,पालने में ऐसे ही झूलती रहे, खुशियों की बहारों में झूमती रहे,गाते मुस्कुराते संगीत की तरह, ये तो लगे रामा की गीत की तरह। रा रा रू रा रा रा रा रू….रा रा रू रा रा रा रा रू"
  ,
"मेरी दुनिया-मेरी दुनिया-मेरी दुनिया तू ही रे,मेरी खुशियां-मेरी खुशियां-मेरी खुशियां तू ही रे, मेरी दुनिया-मेरी दुनिया-मेरी दुनिया तू ही रे,मेरी खुशियां-मेरी खुशियां-मेरी खुशियां तू ही रे,रात दिन तेरे लिए सजदे करूं, दुआएं मांगूं रे,मैं यहां, अपने लिए रब से तेरी बलाएं मांगूं रे। तूने ही जीना सिखाया, हम लोगों को अच्छा इंसां बनाया,जिन्दगी है तेरा साया,अनजानों को सीधा रास्ता दिखाया,तू नई इक रोशनी ले आई है, जीवन की राहों में,हर घड़ी गुजरे तेरी… सारी उम्र अब अपनी बाहों में हमने की जो भी खताएं, हम झेलेंगे उनकी सारी सजा भीहमने की जितनी जफाएं, हम उनसे भी अब करेंगे वफा भीहो हम नए मौसम नया आलम नया, बदले हैं अरमां भीकह रही एहसास की गहराइयां, ठहरा है तूफां भी मेरी दुनिया-मेरी दुनिया-मेरी दुनिया तू ही रे,मेरी खुशियां-मेरी खुशियां-मेरी खुशियां तू ही रे,रात दिन तेरे लिए सजदे करूं, दुआएं मांगूं रे,मैं यहां, अपने लिए रब से तेरी बलाएं मांगूं रे।"
  ,
"तुझे सूरज कहूं या चंदा, तुझे दीप कहूं या तारा,मेरा नाम करेगा रोशन, जग में मेरा राज दुलारा,तुझे सूरज कहूं या चंदा, तुझे दीप कहूं या तारा,मेरा नाम करेगा रोशन, जग में मेरा राज दुलारा। मैं कब से तरस रहा था, मेरे आंगन में कोई खेले,नन्ही-सी हंसी के बदले, मेरी सारी दुनिया ले ले,तेरे संग झूल रहा है मेरी बाहों में जग सारा,मेरा नाम करेगा रोशन, जग में मेरा राज दुलारा। तुझे सूरज कहूं या चंदा, तुझे दीप कहूं या तारा,मेरा नाम करेगा रोशन, जग में मेरा राज दुलारा। आज उंगली थाम के तेरी, तुझे मैं चलना सिखलाऊं,कल हाथ पकड़ना मेरा जब मैं बूढ़ा हो जाऊं,तू मिला तो मैंने पाया, जीने का नया सहारा,मेरा नाम करेगा रोशन, जग में मेरा राज दुलारा। तुझे सूरज कहूं या चंदा, तुझे दीप कहूं या तारा,मेरा नाम करेगा रोशन, जग में मेरा राज दुलारा। मेरे बाद भी इस दुनिया में, जिंदा मेरा नाम रहेगा,जो भी तुझको देखेगा, तुझे मेरा लाल कहेगा,तेरे रूप में मिल जाएगा, मुझको जीवन दोबारा,मेरा नाम करेगा रोशन, जग में मेरा राज दुलारा।तुझे सूरज कहूं या चंदा, तुझे दीप कहूं या तारा,मेरा नाम करेगा रोशन, जग में मेरा राज दुलारा।"
  ,
"वारी जावां वारी जावां वारी जावां, सौ-सौ बारी, सौ-सौ बारी, वारी जावां,वारी जावां वारी जावां वारी जावां, सौ-सौ बारी, सौ-सौ बारी, वारी जावां। सोलह सिंगार करके गोदी भराई ले, सोलह सिंगार करके गोदी भराई ले,सइयां, सइयां, सइयां, सइयां, सइयां से खेली बहुत अब छोटू को खिलाई ले,सोलह सिंगार करके, सोलह सिंगार करके गोदी भराई ले। वारी जावां वारी जावां वारी जावां, सौ-सौ बारी, सौ-सौ बारी, वारी जावांवारी जावां वारी जावां वारी जावां, सौ-सौ बारी, सौ-सौ बारी, वारी जावां छोटू जो आवे घर में, छोटू जो आवे घर में, ओए..होए..ओए..होए..छोटू जो आवे घर में नानी बहलावे, पायल पहन के नानी नाच दिखावे,छोटू जो आवे घर में नानी बहलावे, पायल पहन के नानी नाच दिखावे। वारी जावां वारी जावां वारी जावां, सौ-सौ बारी, सौ-सौ बारी, वारी जावां,वारी जावां वारी जावां वारी जावां, सौ-सौ बारी, सौ-सौ बारी, वारी जावां। हां…छोटू जो आवे घर में, छोटू जो आवे घर में, होए..होए..होए..होए..छोटू जो आवे घर में, मासी को बुलावे, नैपी बदल के उनकी लोरी सुनावे… छोटू जो आवे घर में, आवे उनके मामा,छोटू जो आवे घर में, आवे उनके मामा,दांतों से नाड़ा पकड़े, हाथों से पजामा…हो..ओ… तेरी हंसी भर-भर के, घर में छिड़कावे,हो..ओ… सोलह सिंगार करके गोदी भराई ले,सइयां, सइयां, सइयां सइयां, सइयां से खेली बहुत अब छोटू को खिलाई ले,सोलह सिंगार करके, सोलह सिंगार करके गोदी भराई ले। वारी जावां वारी जावां वारी जावां, सौ-सौ बारी, सौ-सौ बारी, वारी जावां,वारी जावां वारी जावां वारी जावां, सौ-सौ बारी, सौ-सौ बारी, वारी जावां…"
  ,
"यशोमती मैया से बोले नंदलाला,यशोमती मैया से बोले नंदलाला,राधा क्यों गोरी मैं क्यों काला, राधा क्यों गोरी…ओ..ओ.. यशोमती मैया से बोले नंदलालाराधा क्यों गोरी मैं क्यों काला,राधा क्यों गोरी मैं क्यों काला। बोली मुस्काती मैया ललन को बताया,बोली मुस्काती मैया ललन को बताया,कारी अंधियारी आधी रात में तू आया,लाडला कन्हैया मेरा हो…लाडला कन्हैया मेरा, काली कमली वाला, इसीलिए काला। यशोमती मैया से बोले नंदलाला,राधा क्यों गोरी मैं क्यों काला,राधा क्यों गोरी मैं क्यों काला। बोली मुस्काती मैया, सुन मेरे प्यारे,बोली मुस्काती मैया, सुन मेरे प्यारे,गोरी-गोरी राधिका के नैन कजरारे,काले नैनों वाली ने हो…काले नैनों वाली ने ऐसा जादू डाला, इसीलिए काला। यशोमती मैया से बोले नंदलाला,राधा क्यों गोरी मैं क्यों काला,राधा क्यों गोरी मैं क्यों काला।"

  ];
  static const spanish_data = [
    // hindi
 "“आप दोनों के लिए कितने ख़ुशी का दिन है, आप के बच्चे का आगमन बड़े अच्छे से हो ये हम कामना करते है।"
  ,
 "“आपके परिवार में आने वाले नए मेहमान के लिए आप दोनो को ढेर सारी शुभकामनाएं।”"
  ,
 "“आपको गर्भवती होने पर ढेर सारी शुभकामनाएं, आने वाले छोटेसे और नन्हेसे मेहमान को भी बहुत सारी शुभकामनाएं।”"
  ,
 "“आपके घर नया मेहमान आने की ख़ुशी से आप सभी को बहोत बहोत शुभकामनाएं।”"
  ,
 "“आपके परिवार में आने वाले नए मेहमान से मिलने के लिए हम बहुत आतुर हुए है, आपकी प्रसूति सुरक्षित हो, हम यही ईश्वर से यही प्रार्थना करते है।”"
  ,
 "“नया मेहमान आपके यहाँ आएगा, और आपका घर ख़ुशी से झूम उठेगा उस नए मेहमान के आने पर आपको बहोत बहोत शुभकामनाएं।”"
  ,
"बधाई हो!! हम सभी वास्तव में आप दोनों के लिए उत्साहित हैं और आशा करते हैं कि आपका नया बच्चा खुश और स्वस्थ होगा। बहुत शुभकामनाएं।"
  ,
"आपके एक नए जीवन की सफल शुरुआत के लिए बधाई! हम तैयार है नन्ही जान को देखने के लिए।"
  ,
"यह वास्तव में रोमांचक है !!! नए बच्चे के साथ शुभकामनाएं। हम सभी आशा करते हैं कि आपका नवजात शिशु खुश और स्वस्थ हो।"
  ,
"बधाई हो! कोई जल्द ही आ रहा है, जो आपको “मम्मी” कहकर बुलाएगा और आपका जीवन खुशियों से भर देगा। आपको अपनी गर्भावस्था के लिए शुभकामनाएं। आशा है कि यह नया महेमान आपके जीवन को आनंद से भर देगा।"
  ,
"मुझे पता है कि आप एक महान माता-पिता बनने जा रहे हैं। मैं आपको अपने नए बच्चे के साथ देखने के लिए उत्सुक हूं, और मैं खुशी की कामना कर रहा हूं जो आपके जीवन में नए रंग लाएगी|"
  ,
"क्या रोमांचक समय है आप दोनों के लिए !! हमें उम्मीद है कि आपके परिवार के हर सदस्य के लिए खुशी का अवसर होंगा।"
  ,
"हमें गोद भराइ समारोह में आमंत्रित करने के लिए धन्यवाद !! हम आशा करते हैं कि आपका नया नन्हा महेमान आपके जीवन को खुशीयो से भर देंगा|"
  ,
"हम आपके चेहरे पर नई चमक देख सकते हैं- आप निश्चित रूप से अपने पति और परिवार से लाड़ प्यार पा रहे होंगे। आपको और आनेवाले नन्हे महेमान को बहुत शुभकामनाएं |"
  ,
"आप सभी को आपके नइ खुशियों के आगमन की शुभकामनाएं।"
  ,
"हम आपको एक परेशानी मुक्त गर्भावस्था और जल्द ही माता-पिता बनने की शुभकामना करते हैं।"
  ,
"अपने इस खुशियों के आगमन के उत्साह में हमें आमंत्रित करने के लिए धन्यवाद नइ खुशियों आपको बहुत शुभकामनाएं।"
  ,
"आनेवाले महीनों के लिए आप दोनों को शुभकामनाएँ। हम नन्हे महेमान से मिलने का इंतजार कर रहे है!आपके नन्हे चमत्कार के लिए मेरी शुभकामनाएँ।"
  ,
"आपके नन्हे बच्चे के आगमन पर ढेर सारा प्यार और शुभकामनाएं।"
  ,
"इस प्यारी दुनिया में प्यारे आपका स्वागत है। आपको जीवन भर खुशी, हँसी, और खुशी मिले इसके लिए शुभकामनाएं।"
  ,
"अजीब बात है कि इतनी नन्ही जान हमारे दिलों में कितनी जगह ले सकती है। इस जान को बहुत बधाई।"
  ,
"हम आशा करते हैं कि आपके पास आपकी माँ की मुस्कान और आपके पिताजी का हास्य है – बहुत सारा प्यार, नन्ही जान |"
  ,
"गोद भराई के शुभ अवसर पर आपको और आपके बच्चे को हार्दिक शुभकामनाएं।"
  ,
"आपका घर जल्द ही खिलौनों से भर जाएगा और फिर घर खिलखिलाट से बार जायेगा और आप अक्सर थक गए होंगे। लेकिन हमेशा आपके चहेरे पर प्यार और हँसी होगी। आप सभी को शुभकामनाएं और बहुत प्यारी यादें।"
  ,
"कुछ हफ़्ते में, आप माँ बनने जा रहे है! बच्चे के गुलाबी-गाल वाले चेहरे और दो सुंदर आँखों को देखने के लिए हम से अब प्रतीक्षा नहीं हो रही है| हम आपके बच्चे को जानते हैं, चाहे वह लड़की हो या लड़का, आनंद की गठरी होगी। हम आपके नए सुपरस्टार को जल्द ही देखने की उम्मीद कर रहे हैं| आपको और आपके नन्हे बच्चे को आशीर्वाद की शुभकामनाएं|"
  ,
"Hip, Hip, Hurray! आप दोनो सुपर माता-पिता बनाने जा रहे हैं।"
  ,
"बधाई हो! सुपर माता-पिता के रूप में अपनी नई भूमिका को एक शानदार बनाने के लिए हम कामना करते हैं!"
  ,
"एक नन्हा प्यारा बच्चा माता-पिता दोनों के जीवन को रोशन करेगा।"
  ,
"आपकी बेटी सुंदर, स्मार्ट और प्यारी होगी- बिल्कुल अपनी माँ की तरह!"
  ,
"हर बच्चा एक आशीर्वाद है, ऊपर स्वर्ग से एक उपहार!"
  ,
"आपके आने वाले नए खुशी के अवसर पर बधाई! मुझे पता है कि आप एक super mom बनोगी।"
  ,
"नए बच्चे की आगमन की खुसी एक माँ के लिए एक खूबसूरत सपना है। ऐसे खूबसूरत खुशी के अवसर पर बधाई!"
  ,
"मेरे लिए, आप एक सुपर हैं, लेकिन इस नन्ही जान के लिए , आप उनकी पूरी दुनिया हैं – इन आने वाले महीनों के खुशी के अवसर पर बधाई!"
  ,
"आपने इस समय को साबित कर दिया है कि आप कितनी मजबूत और अद्भुत महिला हैं। इन रोमांचक समय के लिए बधाई!"
  ,
"मैं आपके और शिशु दोनों के लिए सुरक्षित और स्वस्थ प्रसव की प्रार्थना कर रहा हूं।"
  ,
"Ho raha naye mehmaan ka intezaar, bhar ke aayega jholi me khushiya hazaar, Hum sab yehi dua karte bhut acha hoga tumhara ye baby shower!"
  ,
"Zindagi ke chote chote pal ka maza hi alag hota hai,\nHaath me jab chota sa bacha hota hai,\nDil se kamanao ke sath bhej rahe aapna pyaar,\nKhushi se manao aapka baby shower!"
  ,
"Lakh lakh badhaiyan aapko,\nMummy papa kehne wala aa raha hai aapko,\nKhush rehna, mast rehna, achi health ki dua aapko,\nBaby shower ki shubhkamnaein aapko!"
  ,
"Choti si ungli thamegi ki bada sa hath,\nBana rahe aapka hamesha sath,\nBaby ho healthy aur ho achi shuruvat,\nAisi badhai deta hai hamara parivar!"
  ,
"Gaano ki dhun gun Guna rahi hu,\nAashirvaad ka paigaam bhej rahi hu,\nBeete khushiyon se aapka baby shower yehi duaein kar rahi hu!"
  ,
"Hasee aapki kabhi kam na ho,\nKisi baat ka koi gam na ho,\nBacha aapka sehatmand ho,\nHumara aashirvaad hai aapka baby shower bhut khubsurat ho!"
  ,
"Chote chote pal ko kaid kar lena,\nTasveer ko frame karva kar rakh lena,\nYe pal dubara nahi aayenge inhe jee bhar ke jee lena,\nApne baby shower me pura maja lena!"
  ,
"Bhag dhaud toh abb shuru hogi,\nJab godi me choti se santan hogi,\nBaby shower me sirf aap ki tareef hogi,\nKyuki agli baar saari baate bache ki hogi!"

      

  ];
}
