class Shayari {
  Shayari._();
  static const shayari_data = [
 
 "“Who knows what it’ll be,If you could reach the addressee. Don’t be a busy bee. Come and share our glee. Honouring our special mom-to-be!”"
  ,
 "“Did you get the forecast? A baby is coming on a sleigh And a shower is coming your way!Please intimate ‘weather’ you can join us”"
  ,
 "“Join us for a baby shower. Do come and grace this hour. Let’s welcome the baby And bless the lady!”"
  ,
 "“Let’s cheer For the D- day is here!And honour our very own dear”"
  ,
 "“Baby shower and Lunch on To welcome our darling munchkin. We invite you thee So, make yourself free!”"
  ,
 "“Do you want sugar or spice? We won’t ask you twice. But we promise you everything nice!Join us for a baby shower to honour”"
  ,
 "“Blissful hearts and happy smiles. Having a baby shortly, meanwhile Those cute little chubby hands and feet Makes everything worthwhile. Let’s have a party in style! Please join us for a baby shower”"
  ,
 "“Save the Date,And don’t be late!Something is cooking in the bun So be there To honour dear”"
  ,
 "“First came love,Then marriage! Now look who’s gracing the baby carriage. Please join us for a baby shower to honour”"
  ,
 "“Baby-o-bash. So, make a dash For all the fun. That’s bound to begin When you sash your way”"
  ,
 "“Nobody knows which way the wind blows! But as the tradition goes Join us for a baby shower to honour dear ”"
  ,
 "“Sail on over And make a stopover!For we’ll be having a makeover To honour our mom-to-be.”"
  ,
 "“Please join us for a Look n Seeto bless the new baby!In honour of mom-to-be.”"
  ,
 "“Bottles, bibs and diapers. A baby’s coming says the piper!Join us for a baby shower honouring dear.”"
  ,
 "“She looks great And we have chosen a date So please be there mate For a baby shower on the eighth”"
  ,
 "“The special day is drawing near. Let’s shower our love and cheer. Join us for a baby shower honouring xyz”"
  ,
 "“Dear Andy is due but she has no clue!A baby shower is in line. So let’s wine and dine”"
  ,
 "“Lots of baby wishes and kisses Who knows for the prince or princess. Join us for a baby shower to honour dear.”"
  ,
 "“Dear is ready to pop!So do make a stop For a baby shower”"
  ,
 "“Ahoy!Twice the love, twice the joy Twice the blessing we seek. Please join us for a baby shower”"
  ,
 "“It’s twins-to-be. We are surely full of gleeLet’s celebrate this yippee To honour dear.”"
  ,
 "“It takes two For magic to brew!So take the cue And join us for celebrations to honour”"
  ,
 "“Two little peanuts Are soon to arrive!Let’s celebrate with cakes and doughnuts Music and jive.Join us for a twin baby shower to honour dear xyz”"
  ,
 "“Dear... is having twins!Let’s get together and give her wings To celebrate and shower our blessings Before her new chapter of life begins!”"
  ,
 "“Twin peas in a pod So much joy in accord!Join us to celebrate the twin baby shower honouring dear xyz”"
  ,
 "“They are expecting two babies. We need to celebrate this ladies!Join us for a baby shower in the honour of”"
  ,
 "“Twenty little fingers, twenty little toesIts double magic, heaven knows!Please join us for a twin baby shower”"
  ,
 "“Two precious bundles of joy. What more can one ask for oh Boy!Four tiny arms to hug on tight. Four cute cheeks to kiss nighty-night!We are thrilled to announce a baby shower for our twins”"
  ,
 "“Twice the boon we are over the moon Twice the delight We are eager to invite For a baby shower to honour dear.”"
  ,
 "“One, two! much to do!Twice the fun is coming our way So let’s celebrate this exciting day Join us for a twin baby shower”"
  ,
 "“Want a clue? We’re expecting two!A celebration is due Join us for a baby shower in honouring ”"
  ,
 "“We got blessed twice!Oh! Isn’t it nice?Be a part of our paradise”"
  ,
 "“Good blessings come in pairs God answered our prayers!So please come and share Our joy at twin baby shower”"
  ,
 "“Double Bonanza! Double the Fun!We have a party spun Join the celebrations to honour dear.”"
  ,
 "Parenting is usually a team effort where the mother and father both play an equally important role. So, it makes sense to celebrate the arrival of a baby together as a couple. Some of the ideas for couple’s baby shower invitations can be:“A baby is Brewing!Let’s raise a toast to celebrate our new additionPlease join us for a couple’s baby shower bash to wife and husband.”"
  ,
 "“We’ve travelled all over seeking thrills! We are about to begin our life’s greatest adventure. Join us on our exciting trip as we welcome the arrival of our baby”"
  ,
 "“We’re firing up the grill. There is a bun in the oven!Join us for a BBQ as we celebrate the baby-to-be”"
  ,
 "“Books are the best companions!Skip the card and bring along your favourite book. As we celebrate the birth of our baby For Books and Brunch In the honour of parents-to-be.”"
  ,
 "“Nisha’s baby is almost here!So, let’s gear up for some cheer And celebrate with chilled beer. Join us for a cool baby shower”"
  ,
 "“Babies are so cute and such fun. We’re going for another one!In the honour of dear.”"
  ,
 "“We’re proud to say Another baby is on the way!Please join us to brighten our day As we celebrate the arrival of our little one”"
  ,
 "“Two little hands and cute little feet One more baby makes our sweet family complete!Please join us for a baby sprinkle in the honour of dear.”"
  ,
 "“Someone lovely someone bubbly Someone cuddly someone chubby To love and cherish is here. Let’s celebrate with a hearty cheer!Join us in showering dear with a baby sprinkle”"
  ,
 "“We are in for our second innings. It’s time for new beginnings. We sure are grinning As our world is again spinning. Please join us as we celebrate a baby sprinkle in honour of dear.”"
  

  ];
}
