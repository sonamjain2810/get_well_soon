package com.example.get_well_soon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
